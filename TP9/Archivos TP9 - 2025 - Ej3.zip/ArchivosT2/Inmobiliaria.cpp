#include "Inmobiliaria.h"

Inmobiliaria::Inmobiliaria(int cod, string nomb, string cuit){
	this->codigoAFIP=cod;
	this->nombreEmpresa=nomb;
	this->CUIT=cuit;

	//COMPLETAR INICIALIZACI�N DE ATRIBUTOS SI ES NECESARIO

}

void Inmobiliaria::alquilar(/*COMPLETAR CON LOS PARAMETROS ADECUADOS*/){

	//COMPLETAR DE ACUERDO A LOS PARAMETROS RECIBIDOS

	/*
	 * El tipo de alquiler se determina teniendo en cuenta la duraci�n.
	 * Un alquiler de 6 meses o mas corresponde a un alquiler Permanente,
	 * en otro caso, se considera un alquiler de tipo Temporal.
	 */
}

void Inmobiliaria::resumen(){

	//COMPLETAR DE ACUERDO AL DIAGRAMA UML

}

Inmobiliaria::~Inmobiliaria(){

	//SI ES NECESARIO COMPLETAR EL DESTRUCTOR

}





