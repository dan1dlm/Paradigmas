#ifndef INMOBILIARIA_H_
#define INMOBILIARIA_H_

#include <iostream>

#include "Alquiler.h"

class Inmobiliaria {
	int codigoAFIP;
	string nombreEmpresa;
	string CUIT;

	//COMPLETAR ATRIBUTOS SI ES NECESARIO

public:
	Inmobiliaria(int cod, string nom, string cuit);
	void alquilar(/*COMPLETAR CON LOS PARAMETROS ADECUADOS*/);
	void resumen();
	virtual ~Inmobiliaria();
};

#endif /* INMOBILIARIA_H_ */
