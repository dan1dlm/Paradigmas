#ifndef ALQUILER_H_
#define ALQUILER_H_

#include <iostream>
#include "Inmueble.h"
#include "Fecha.h"

using namespace std;

class Alquiler {
	static int autonumerico;
	int codigo;
	int idCliente;
	Fecha fechaInicio;
	Fecha fechaFin;

	//COMPLETAR ATRIBUTOS SI ES NECESARIO

protected:
	int getCantidadMeses();

public:
	Alquiler(int id, Fecha fechaI, Fecha fechaF);

	double calcularCosto();
	void listarInfo();
	virtual ~Alquiler();
};

#endif /* ALQUILER_H_ */
